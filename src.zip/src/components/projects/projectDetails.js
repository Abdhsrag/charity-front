function ProjectDetails() {
  return (
    <div className="project-details">
      <h1>Project Details</h1>
      <p>This is where the details of a specific project will be displayed.</p>
    </div>
  );
}

export default ProjectDetails;